//go:build tools
// +build tools

package tools

import (
	_ "github.com/dvyukov/go-fuzz/go-fuzz-build"
	_ "honnef.co/go/tools/cmd/staticcheck"
)
