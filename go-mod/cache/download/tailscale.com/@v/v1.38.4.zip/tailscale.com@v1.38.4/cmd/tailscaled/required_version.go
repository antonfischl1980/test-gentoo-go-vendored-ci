// Copyright (c) Tailscale Inc & AUTHORS
// SPDX-License-Identifier: BSD-3-Clause

//go:build !go1.20

package main

func init() {
	you_need_Go_1_20_to_compile_Tailscale()
}
