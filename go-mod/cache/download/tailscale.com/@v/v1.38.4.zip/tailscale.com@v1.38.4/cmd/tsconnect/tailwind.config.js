/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.html", "./src/**/*.ts", "./src/**/*.tsx"],
  theme: {
    extend: {},
  },
  plugins: [],
}
