// Copyright (c) Tailscale Inc & AUTHORS
// SPDX-License-Identifier: BSD-3-Clause

package ipnserver

import "net/http"

func (s *Server) handleProxyConnectConn(w http.ResponseWriter, r *http.Request) {
	panic("unreachable")
}
