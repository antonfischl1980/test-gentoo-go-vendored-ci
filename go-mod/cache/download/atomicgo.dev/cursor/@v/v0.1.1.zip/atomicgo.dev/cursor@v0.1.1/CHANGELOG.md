<a name="unreleased"></a>
## [Unreleased]


<a name="v0.0.1"></a>
## v0.0.1 - 2021-05-09
### Features
- implement `Area`
- add `ClearLinesUp` and `ClearLinesDown`
- implement cross-platform support
- implement cursor functions

### Bug Fixes
- height can no longer be negative on non windows systems

### Code Refactoring
- remove debug code


[Unreleased]: https://github.com/MarvinJWendt/testza/compare/v0.0.1...HEAD
