/* SPDX-License-Identifier: GPL-2.0
 *
 * Copyright (C) 2020-2021 Jason A. Donenfeld. All Rights Reserved.
 */

#ifndef _VERSION_H
#define _VERSION_H

#define VERSION_STR "1.0"
#define VERSION_ARRAY 1,0,0,0

#endif
