## [v0.2.1](https://gitea.com/gitea/gitea-vet/releases/tag/v0.2.1) - 2020-08-15

* BUGFIXES
  * Split migration check to Deps and Imports (#9)

## [0.2.0](https://gitea.com/gitea/gitea-vet/pulls?q=&type=all&state=closed&milestone=1272) - 2020-07-20

* FEATURES
  * Add migrations check (#5)
* BUGFIXES
  * Correct Import Paths (#6)
