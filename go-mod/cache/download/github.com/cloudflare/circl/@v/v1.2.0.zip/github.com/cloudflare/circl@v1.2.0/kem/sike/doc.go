//go:generate go run gen.go

// Package sike contains the SIKE key encapsulation mechanism.
package sike
