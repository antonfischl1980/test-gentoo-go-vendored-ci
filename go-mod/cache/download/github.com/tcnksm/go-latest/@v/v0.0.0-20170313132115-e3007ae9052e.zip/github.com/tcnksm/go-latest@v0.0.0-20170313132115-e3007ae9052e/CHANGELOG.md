## 0.1.1 (2015-04-14)

Add `latest` command

### Added

- `DeleveFrontV()` function to delete font `v` charactor
- `latest` command in `cmd` diretory, to check version is latest or not from command line

### Deprecated

- Nothing

### Removed

- Nothing

### Fixed

- More documentation


## 0.1.0 (2015-04-07)

Initial release

### Added

- Fundamental features

### Deprecated

- Nothing

### Removed

- Nothing

### Fixed

- Nothing


