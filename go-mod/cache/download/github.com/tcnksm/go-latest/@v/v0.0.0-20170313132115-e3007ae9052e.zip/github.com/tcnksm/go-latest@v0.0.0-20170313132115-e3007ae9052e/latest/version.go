package main

const Name = "latest"
const Version = "0.1.1"

var GitCommit = ""
