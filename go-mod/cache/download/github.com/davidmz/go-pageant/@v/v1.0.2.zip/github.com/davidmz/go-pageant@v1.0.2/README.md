[![GoDoc](https://godoc.org/github.com/davidmz/go-pageant?status.svg)](https://godoc.org/github.com/davidmz/go-pageant)

Package pageant provides an interface to PyTTY pageant.exe utility.

This package is windows-only.

See documentation on [GoDoc](http://godoc.org/github.com/davidmz/go-pageant)

License: MIT