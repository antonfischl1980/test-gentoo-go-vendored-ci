// Helper package to add more functions to httpmock (github.com/jarcoal/httpmock)
//
// Features:
// - RegisterQueryMapResponder form query based based on a QueryMap
// - ActivateRecorder to record HTTP requests during the development of tests and examples
package checkhttpmock
