We would like to acknowledge previous OCI image spec maintainers and their huge contributions to our collective success:

* Brandon Philips (@philips)
* Brendan Burns (@brendandburns)
* Jason Bouzane (@jbouzane)
* John Starks (@jstarks)
* Keyang Xie (@xiekeyang)

We thank these members for their service to the OCI community.
