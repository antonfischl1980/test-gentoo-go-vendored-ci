| Label  | Value |
| ------ | ----- |
| First  | foo   |
| Second | bar   |
