This text is **strong**.
