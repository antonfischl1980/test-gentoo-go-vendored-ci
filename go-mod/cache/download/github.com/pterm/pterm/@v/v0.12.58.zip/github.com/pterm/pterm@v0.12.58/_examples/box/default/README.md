# box/default

![Animation](animation.svg)

```go
package main

import "github.com/pterm/pterm"

func main() {
	pterm.DefaultBox.Println("Hello, World!")
}

```
