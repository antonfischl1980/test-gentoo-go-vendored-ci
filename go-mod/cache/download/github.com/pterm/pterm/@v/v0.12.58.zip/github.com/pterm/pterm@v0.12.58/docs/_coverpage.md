<img src="_assets/images/pterm_logo.png" alt="PTerm Logo" width="400"/>

> PTerm is a modern go module to beautify console output.

- ☁ Lightweight ☁
- 🪀 Super easy usage 🪀
- ♾ Infinite possibilities ♾
- 🐙 Open Source 🐙

[Quick Start](quick-start.md)
[Documentation](docs/intro.md)
[GitHub](https://github.com/pterm/pterm/)