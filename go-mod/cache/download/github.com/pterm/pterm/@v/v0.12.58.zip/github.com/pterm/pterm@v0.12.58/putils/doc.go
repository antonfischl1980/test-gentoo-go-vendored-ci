// Package putils contains utility functions for PTerm, to make it's usage even easier!
// It contains pre-made functions, that utilize PTerm, to print various stuff to the terminal.
// You can use PUtils, to simplify various scenarios for which PTerm is frequently used.
package putils
