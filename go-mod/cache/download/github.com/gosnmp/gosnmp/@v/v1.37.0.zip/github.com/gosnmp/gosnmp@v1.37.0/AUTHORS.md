# GoSNMP authors

`git log --pretty=format:"* %an %ae" df49b4fc0b10ed2cab253cecc8c3d86b72cec41d..HEAD | sort -f | uniq >> AUTHORS.md`

`TODO: something clever with sed, etc to autogenerate this`

* 10074432 liu.xuefeng1@zte.com.cn
* Andreas Louca andreas@louca.org
* Andrew Filonov aef@bks.tv
* Andris Raugulis moo@arthepsy.eu
* Balogh Ákos akos@rubin.hu
* Benjamin benjamin.guy.thomas@gmail.com
* Benjamin Thomas benjamin.guy.thomas@gmail.com
* Ben Kochie superq@gmail.com
* benthor github@benthor.name
* Brian Brazil brian.brazil@robustperception.io
* Bryan Hill bryan.d.hill@gmail.com
* Bryan Hill bryan.hill@ontario.ca
* Chris chris.dance@papercut.com
* codedance dance.chris@gmail.com
* Daniel Swarbrick daniel.swarbrick@gmail.com
* davidbj david_bj@126.com
* David Riley fraveydank@gmail.com
* Douglas Heriot git@douglasheriot.com
* dramirez dramirez@rackspace.com
* Dr Josef Karthauser joe@truespeed.com
* Eamon Bauman eamon@eamonbauman.com
* Eduardo Ferro Aldama eduardo.ferro.aldama@gmail.com
* Eduardo Ferro eduardo.ferro.aldama@gmail.com
* Eli Yukelzon reflog@gmail.com
* Felix Maurer felix@felix-maurer.de
* frozenbubbleboy github@wildtongue.net
* geofduf 46729592+geofduf@users.noreply.github.com
* Guillem Jover gjover@sipwise.com
* HD Moore x@hdm.io
* Igor Novgorodov igor@novg.net
* Ivan Radakovic iradakovic13@gmail.com
* jacob dubinsky dubinskyjm@gmail.com
* Jacob Dubinsky dubinskyjm@gmail.com
* Jaime Gil de Sagredo Luna jgil@alea-soluciones.com
* Jan Kodera koderja2@fit.cvut.cz
* Jared Housh j.housh@f5.com
* jclc jclc@protonmail.com
* Joe Cracchiolo jjc@simplybits.com
* Jon Auer jda@coldshore.com
* Jon Auer jda@tapodi.net
* Joshua Green joshua.green@mail.com
* JP Kekkonen karatepekka@gmail.com
* kauppine 24810630+kauppine@users.noreply.github.com
* Kauppine 24810630+kauppine@users.noreply.github.com
* Kian Ostvar kiano@jurumani.com
* krkini16 krkini16@users.noreply.github.com
* lilinzhe slayercat.registiononly@gmail.com
* lilinzhe slayercat.subscription@gmail.com
* Marc Arndt marcarndt@Marcs-MacBook-Pro.local
* Marc Arndt marc@marcarndt.com
* Martin Lindhe martinlindhe@users.noreply.github.com
* Marty Schoch marty.schoch@gmail.com
* Mattias Folke mattias.folke@gmail.com
* Mattias Folke mattias.folke@tre.se
* Mehdi Pourfar mehdipourfar@gmail.com
* meifakun runner.mei@gmail.com
* Michał Derkacz michal@Lnet.pl
* Michel Blanc mb@mbnet.fr
* Miroslav Genov mgenov@gmail.com
* Nathan Owens nathan_owens@cable.comcast.com
* Nathan Owens virtuallynathan@gmail.com
* NewHooker yaocanwu@gmail.com
* nikandfor nikandfor@gmail.com
* Patrick Hemmer patrick.hemmer@gmail.com
* Patryk Najda ptrknjd@gmail.com
* Paul Komkoff i@stingr.net
* Peter Vypov peter.vypov@gmail.com
* pschou pschou@users.noreply.github.com
* Rene Fragoso ctrlrsf@gmail.com
* rjammalamadaka rajanikanth.jammalamadaka@mandiant.com
* Ross Wilson ross.wilson@iomart.com
* Sonia Hamilton sonia@snowfrog.net
* StefanHauth 63204425+StefanHauth@users.noreply.github.com
* Stefan Hauth stefan.hauth@dynatrace.com
* Tara taramerin@gmail.com
* The Binary binary4bytes@gmail.com
* Tim Rots tim.rots@protonmail.ch
* toni-moreno toni.moreno@gmail.com
* Vallimamod Abdullah vma@users.noreply.github.com
* WangShouLin wang.shoulin1@zte.com.cn
* Whitham D. Reeve II thetawaves@gmail.com
* Whitham D. Reeve II wreeve@gci.com
* x1unix ascii@live.ru
