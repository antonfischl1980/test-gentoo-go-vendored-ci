package terminal

type Short int16

type Coord struct {
	X Short
	Y Short
}
